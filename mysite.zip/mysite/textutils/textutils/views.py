from gettext import dgettext
from mailbox import linesep
from django.http import HttpResponse
from django.shortcuts import render

# def test(request):
#     return HttpResponse("Hello World")

# def Harry(request):
#     return HttpResponse('''<a href="https://www.youtube.com/watch?v=AepgWsROO4k&list=PLu0W_9lII9ah7DDtYtflgwMwpT3xmjXY9&index=7"> Django Code With Harry</a>''')


def index(request):
    # return HttpResponse("Home")
    param = {'name':'Naveed','place':'Shalmani'}
    return render(request, 'index.html',param)



def analyze(request):
    djtext=request.POST.get('text','default')
    removepun = request.POST.get('removepun','off')
    fullcaps = request.POST.get('fullcaps','off')
    newlineremove = request.POST.get('newlineremove','off') 
    removespace = request.POST.get('removespace','off')
    charcount = request.POST.get('charcount','off')
    lowerlatter = request.POST.get('lowerlatter','off')

    # remove punctulations with django in python 
    print(removepun)
    print(djtext)
    if removepun == "on":
        punctulatuion = '''!-(){};:"\,<>./?@#$%&*^~'''
        analyzed = ""
        for char in djtext:
            if char not in punctulatuion:
                analyzed = analyzed + char
        params = {'purpose':'Remove Punctulation','analyzed_text':analyzed}
        djtext = analyzed
        # return render(request, 'analyze.html', params)

        # char uppercase
    if (fullcaps == "on"):
        analyzed = ""
        for char in djtext:
            analyzed = analyzed + char.upper()
        params = {'purpose':'change to uppercase','analyzed_text':analyzed}
        djtext = analyzed
        # return render(request,'analyze.html',params)

        # Remove new line 
    if (newlineremove == "on"):
        analyzed = ""
        for char in djtext:
            if char !="\n" and char !="\r":
                analyzed = analyzed + char
        
        params = {'purpose':'Remove New line', 'analyzed_text':analyzed}
        djtext = analyzed
        # return render(request,'analyze.html',params)

        # Remove space 
    if (removespace == "on"):
        analyzed = ""
        for index, char in enumerate(djtext):
            if not(djtext[index] ==" " and djtext[index + 1]==" "):
                analyzed = analyzed + char
        params = {'purpose':'Remove Space ','analyzed_text':analyzed}
        djtext = analyzed
        # return render(request,'analyze.html',params)
    
    if (charcount == "on"):
        charcount = 0
        for i in str(djtext):
            charcount += 1
        
        params = {'purpose':'Character count','analyzed_text':charcount}
        djtext = analyzed
        # return render(request,'analyze.html',params)
    
    if (lowerlatter == "on"):
        analyzed = ""
        for char in djtext:
            analyzed = analyzed + char.lower()
        
        params = {'purpose':'Lower Latter','analyzed_text':analyzed}
        # djtext = analyzed
        # return render(request,'analyze.html',params)
            
    
    if(removepun !="on" and fullcaps !="on" and newlineremove !="on" and removespace !="on" and charcount !="on"):
        return HttpResponse("Please Select any Operations")

    # else:
    #     return HttpResponse("Error")
    
    return render(request,'analyze.html',params)

    

# def capfirst(request):
#     return HttpResponse("captilize function")

# def backspace(request):
#     return HttpResponse("backspace <a href='/'> back </a>")